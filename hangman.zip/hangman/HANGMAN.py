import random

import h

word_list = ["apple" , "banana" , "cherry" , "watermelon" , "orange"]
print(word_list)

chosen_word = random.choice(word_list)
print(chosen_word)

lives = len(chosen_word)
display1 = []

for x in range(len(chosen_word)):
    display1 += "_"

print(display1)

game_over = False

while not game_over:

    letter_guessed = input("enter any letter  : ")

    for position in range(len(chosen_word)):
        letter = chosen_word[position]
        if letter == letter_guessed:
          display1[position] = letter_guessed 
          print(display1)
    if letter_guessed not in chosen_word:
        lives -= 1

        if lives == 0 :
            game_over = True
            print("you lose")

    if  "_" not in display1:
        game_over = True
        print("you win")

    print(h.stages[lives])    
        